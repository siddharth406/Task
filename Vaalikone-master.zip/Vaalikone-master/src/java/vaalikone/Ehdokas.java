/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package vaalikone;

/**
 *
 * @author vivesanto
 */
public class Ehdokas extends Kayttaja{
    private int ehdokasId;
}
